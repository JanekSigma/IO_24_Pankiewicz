package zse.spec.oop;

import java.util.List;

public class World {
    public static void main(String[] args) {
        System.out.println("=== System wystartował ===");

        // Test obiektów Vector2d
        Vector2d position1 = new Vector2d(1, 2);
        System.out.println("Pozycja 1: " + position1);

        Vector2d position2 = new Vector2d(-2, 1);
        System.out.println("Pozycja 2: " + position2);

        System.out.println("Suma pozycji: " + position1.add(position2));

        // Testowanie obiektów MapDirection
        MapDirection direction = MapDirection.NORTH;

        System.out.println("\n--- Kierunki ---");
        System.out.println("Początkowy kierunek: " + direction);
        System.out.println("Kolejny kierunek: " + direction.next());
        System.out.println("Poprzedni kierunek: " + direction.previous());

        Vector2d unitVector = direction.toUnitVector();
        System.out.println("Jednostkowy wektor dla " + direction + ": " + unitVector);

        // Tworzenie zwierzęcia z domyślnymi wartościami
        MapDirection.Animal animal = new MapDirection.Animal();
        System.out.println("\n" + animal); // Pozycja startowa i orientacja NORTH

        // Przetwarzanie argumentów wejściowych na kierunki
        List<MoveDirection> directions = OptionsParser.parse(args);

        // Poruszanie zwierzęcia zgodnie z kierunkami
        System.out.println("\n--- Ruchy zwierzęcia ---");
        for (MoveDirection moveDirection : directions) {
            animal.move(moveDirection);
            System.out.println(animal); // Wyświetlanie stanu zwierzęcia po każdym ruchu
        }

        System.out.println("\n=== System zakończył działanie ===");
    }
}