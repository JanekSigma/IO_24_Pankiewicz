package zse.spec.oop;

import java.util.ArrayList;
import java.util.List;

public class OptionsParser {
    public static List<MoveDirection> parse(String[] directions) {
        List<MoveDirection> result = new ArrayList<>();

        for (String direction : directions) {
            switch (direction) {
                case "f" -> result.add(MoveDirection.FORWARD);
                case "b" -> result.add(MoveDirection.BACKWARD);
                case "r" -> result.add(MoveDirection.RIGHT);
                case "l" -> result.add(MoveDirection.LEFT);
                default -> {
                    // Ignorowanie nieprawidłowych opcji
                }
            }
        }

        return result;
    }
}