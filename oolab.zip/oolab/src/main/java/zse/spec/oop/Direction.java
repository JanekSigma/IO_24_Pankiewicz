package zse.spec.oop;

public enum Direction {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT
}